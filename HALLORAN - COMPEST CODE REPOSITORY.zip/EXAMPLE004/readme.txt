This example of a simple heat transport in porous 
media model is presented in the article's 
Supplementary Information file. This example is 
unrelated to the isotope fractionation models of 
examples 1-3 and is intended to demonstrate how 
COMPEST may be used for other multiphysics 
applications. 
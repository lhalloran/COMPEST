EXAMPLE001.pst uses both deltaC_PCE and  data
EXAMPLE001a.pst uses only deltaC_PCE data
EXAMPLE001a.pst uses only PCE concentration data